from django.contrib import admin
from . models import Cart, Product,Order
from . models import Customer
from django.contrib.auth.models import Group
# Register your models here.
@admin.register(Product)
class ProductModelAdmin(admin.ModelAdmin):
    list_display=['id','title','discounted_price','category','product_image']

@admin.register(Customer)
class CustomerModelAdmin(admin.ModelAdmin):
    list_display=['id','user','name','city']

@admin.register(Cart)
class CartModelAdmin(admin.ModelAdmin):
    list_display=['id','user','product','quantity']

@admin.register(Order)
class OrderModelAdmin(admin.ModelAdmin):
    list_display=['id', 'user', 'product', 'quantity', 'ordered_at']



admin.site.unregister(Group)
